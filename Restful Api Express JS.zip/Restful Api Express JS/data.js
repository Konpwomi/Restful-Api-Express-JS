const data = [
    {
        id: '1',
        name: 'ต้มยำหมูเด้งไส้ชีส by chef เหม่งตลาดพลู - ตลาดพลู',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-CZEGME2WEBX1RA/hero/bbc65013b5f942d9bf34bd6b890363ce_1588659289934224875.webp',
        type: 'fastfood'
    },
    {
        id: '2',
        name: 'ขาหมู ตามสั่งเจ้าเก่า บางแค Byเจ๊พร - เพชรเกษม',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-CZKXBGC2LBVJRE/hero/510e0c0a2b5240799a220447cb15d8e8_1593573713269846059.webp',
        type: 'Coupon, ข้าวหน้า, อาหารตามสั่ง, ปิ้งย่าง/บาร์บีคิว'
    },
    {
        id: '3',
        name: 'สั่ง - ถนนเจริญนคร 46',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-CY2FEKVUGN22N6/hero/73e73b7cb9d843319c58a97c99d9481f_1599140637189954146.webp',
        type: 'Coupon, อาหารตามสั่ง'
    },
    {
        id: '4',
        name: 'สุกี้บรรลือโลก - หน้าวัดสำโรง',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-CZMUGRLHUFEHN6/hero/47795477-4778-4500-b3ac-6ef5ac569cae__store_cover__2023__01__19__03__05__23.webp',
        type: 'Coupon, อาหารตามสั่ง'
    },
    {
        id: '5',
        name: 'มรกตสยาม หวานเย็นสูตรโบราณ - พรานนก',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-C3KHCJJEAT3HGE/hero/8deb810958cd4ea2b0cad9badec164cb_1652712104064708484.webp',
        type: 'Coupon, น้ำแข็งไส'
    },
    {
        id: '6',
        name: 'Ginza16 (กินซ่า16) - บางกรวย-ไทรน้อย 13',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-C2TBCYKJRA4BGJ/hero/15e26e674fa84055a5b68ab30ef50042_1653385519141676633.webp',
        type: 'ติ่มซำ, ข้าวหน้า, Coupon, ฟาสต์ฟู้ด'
    },
    {
        id: '7',
        name: 'เมี่ยงปลาเผา S81 - ซอยสุขุมวิท 81',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-C3BDWAEGG763G2/hero/2919af1901924360936bc847cc2f6446_1652499389214732989.webp',
        type: 'cpupon, fastfood'
    },
    {
        id: '8',
        name: 'กุ้งอบวุ้นเส้น (ลงเรือ) - ตลาดพลู',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/THGFIST00000157/hero/200019604_35303a70481146e288be3c36e6edbe14_1549945685252371878.webp',
        type: 'Coupon, อาหารเส้น'
    },
    {
        id: '9',
        name: 'สเต็กกินกับ อาหารคลีน ร้านดัง บางแวก - บางแวก 62',
        imageUrl: 'https://d1sag4ddilekf6.cloudfront.net/compressed_webp/merchants/3-C3KDRPVKHFU3ET/hero/a25d75e8edc14e3e911d198d999983df_1652373649415521671.webp',
        type: 'Coupon, อาหารสุขภาพ'
    }
];







module.exports = data;